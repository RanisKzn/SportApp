﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SportApp
{
    /// <summary>
    /// Логика взаимодействия для WorkWithItem.xaml
    /// </summary>
    public partial class WorkWithItem : Window
    {

        private user25Entities context = new user25Entities();
        public WorkWithItem()
        {
            InitializeComponent();
            var list = context.Product.OrderBy(x => x.ProductName).ToList();
            listA.ItemsSource = list;
            filter.ItemsSource = new List<String>(){
                "0-10%","10-15%","15-100%", "all range"
            };
        }

        private void filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(filter.SelectedIndex == 1)
            {
                var list = context.Product.Where(u => u.ProductDiscountAmount > 0 && u.ProductDiscountAmount < 10).ToList();
                listA.ItemsSource = list;
            }
            if (filter.SelectedIndex == 2)
            {
                var list = context.Product.Where(u => u.ProductDiscountAmount > 10 && u.ProductDiscountAmount < 15).ToList();
                listA.ItemsSource = list;
            }
        }
    }
}
